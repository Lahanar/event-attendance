window.APP_CONFIG = {
  // '' = ใช้ relative path (หน้าเว็บเสิร์ฟจากเซิร์ฟเวอร์เดียวกับ API)
  // หรือกำหนด URL ของ API เช่น 'https://your-api.onrender.com'
  API_BASE_URL: ''
};
